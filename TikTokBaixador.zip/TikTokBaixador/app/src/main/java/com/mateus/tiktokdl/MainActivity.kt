package com.mateus.tiktokdl

import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var campoLink: EditText
    private lateinit var botaoBaixar: Button
    private lateinit var progresso: ProgressBar
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        campoLink = findViewById(R.id.campoLink)
        botaoBaixar = findViewById(R.id.botaoBaixar)
        progresso = findViewById(R.id.progresso)
        status = findViewById(R.id.status)

        findViewById<Button>(R.id.botaoColar).setOnClickListener { colarLink() }
        botaoBaixar.setOnClickListener { baixar() }

        // Se o link chegou pelo botão "Compartilhar" do TikTok
        receberCompartilhamento(intent)

        // Prepara o yt-dlp (só na primeira vez demora um pouco)
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                YoutubeDL.getInstance().init(applicationContext)
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    status.text = "Erro ao preparar o app: ${e.message}"
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        receberCompartilhamento(intent)
    }

    private fun receberCompartilhamento(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND) {
            val texto = intent.getStringExtra(Intent.EXTRA_TEXT) ?: return
            campoLink.setText(extrairLink(texto))
        }
    }

    // O TikTok às vezes compartilha texto + link; pegamos só o link
    private fun extrairLink(texto: String): String {
        val achado = Regex("https?://\\S+").find(texto)
        return achado?.value ?: texto.trim()
    }

    private fun colarLink() {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val texto = clipboard.primaryClip?.getItemAt(0)?.text?.toString()
        if (texto.isNullOrBlank()) {
            Toast.makeText(this, "Nada para colar", Toast.LENGTH_SHORT).show()
        } else {
            campoLink.setText(extrairLink(texto))
        }
    }

    private fun baixar() {
        val link = extrairLink(campoLink.text.toString())
        if (!link.contains("tiktok.com")) {
            status.text = "Cole um link válido do TikTok."
            return
        }

        botaoBaixar.isEnabled = false
        progresso.progress = 0
        progresso.visibility = android.view.View.VISIBLE
        status.text = "Baixando..."

        lifecycleScope.launch {
            val resultado = withContext(Dispatchers.IO) {
                try {
                    val pasta = File(cacheDir, "downloads").apply { mkdirs() }
                    val request = YoutubeDLRequest(link).apply {
                        addOption("-o", "${pasta.absolutePath}/%(id)s.%(ext)s")
                        addOption("-f", "mp4/best")
                    }
                    YoutubeDL.getInstance().execute(request) { porcentagem, _, _ ->
                        runOnUiThread { progresso.progress = porcentagem.toInt() }
                    }
                    val arquivo = pasta.listFiles()
                        ?.maxByOrNull { it.lastModified() }
                        ?: error("Arquivo não encontrado")
                    salvarNaGaleria(arquivo)
                    arquivo.delete()
                    "Pronto! Vídeo salvo na pasta Downloads."
                } catch (e: Exception) {
                    "Não consegui baixar. Confira o link e se o vídeo é público."
                }
            }
            status.text = resultado
            progresso.visibility = android.view.View.GONE
            botaoBaixar.isEnabled = true
        }
    }

    // Copia o vídeo para a pasta Downloads do celular
    private fun salvarNaGaleria(arquivo: File) {
        val valores = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, "tiktok_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Downloads.MIME_TYPE, "video/mp4")
            put(MediaStore.Downloads.RELATIVE_PATH, "Download")
        }
        val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, valores)
            ?: error("Não foi possível criar o arquivo")
        contentResolver.openOutputStream(uri)?.use { saida ->
            arquivo.inputStream().use { entrada -> entrada.copyTo(saida) }
        }
    }
}
