# Baixar TikTok (app Android)

App que baixa vídeos do TikTok só com o link. O yt-dlp roda dentro do próprio app, sem servidor.

## Como gerar o APK

1. Instale o **Android Studio** (developer.android.com/studio).
2. Abra o Android Studio → **Open** → escolha a pasta `TikTokBaixador`.
3. Espere o "Gradle Sync" terminar (baixa as dependências, leva alguns minutos).
4. No menu: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Quando terminar, clique em **locate**. O arquivo `app-debug.apk` estará lá.
6. Passe o APK para o celular, abra e instale (permita "instalar apps desconhecidos").

Dica: ligue o celular por cabo USB com a depuração USB ativada e clique no botão ▶ (Run) para instalar direto.

## Como usar

- No TikTok: **Compartilhar → escolha "Baixar TikTok"**, e depois toque em **Baixar**.
- Ou abra o app, toque em **Colar link** e depois em **Baixar**.
- O vídeo é salvo na pasta **Downloads** do celular.

## Aviso

Use só para vídeos seus ou para uso pessoal. Baixar e repostar vídeos de outras pessoas pode violar os termos do TikTok e direitos autorais.

## Se der erro no Gradle Sync

A versão da biblioteca (`youtubedl-android`) em `app/build.gradle.kts` pode estar desatualizada. Troque por a versão mais recente da biblioteca `io.github.junkfood02.youtubedl-android` e sincronize de novo. Se o TikTok mudar algo, o yt-dlp precisa ser atualizado também.
